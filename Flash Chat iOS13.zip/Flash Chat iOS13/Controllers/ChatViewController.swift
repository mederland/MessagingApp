import UIKit
import Firebase

class ChatViewController: UIViewController {
    
    
   

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextfield: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "US Team Chat App"
        navigationItem.hidesBackButton = true

    }
    
    @IBAction func sendPressed(_ sender: UIButton) {
        
        
//        let sms = Database.database().reference().child("posts").childByAutoId()
//
//        let postObject = [
//         "text": messageTextfield.text,
//         "timestamp":[".sv":"timestamp"]
//
//        ] as [String: Any]
//
//        sms.setValue(postObject, withCompletionBlock: { error, ref in
//            if error == nil {
//                self.dismiss(animated: true, completion: nil)
//            } else {
//                // Handle the error
//            }
//        })

        let dateMessage = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMddyyyyHHmmss"
        let idDate = dateFormatter.string(from: dateMessage)
        let sms = Database.database().reference().child("messages").child(idDate)
                
        dateFormatter.dateFormat = "MM/dd/yyyy HH:mm:ss"
                
        //        Message(content: "how are you", timestamp: idDate, messageId: "12345", userSenderId: 0001)
                
        let postObject = [
                            "content": messageTextfield.text ?? "No Message",
                            "timestamp": dateFormatter.string(from: dateMessage),
                            "messageId": idDate,
                            "userSenderId": Auth.auth().currentUser?.uid ?? "Unknown"] as [String: Any]
                
        sms.setValue(postObject, withCompletionBlock: {error, ref in
            if error == nil {
                        
            } else {
                print("Error")
                    }
            })
        
        
        
        
        
    }
    
    @IBAction func logOut(_ sender: UIBarButtonItem) {
        
        do {
            try Auth.auth().signOut()
            navigationController?.popToRootViewController(animated: true)
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
      
        
    }
    
    

}
